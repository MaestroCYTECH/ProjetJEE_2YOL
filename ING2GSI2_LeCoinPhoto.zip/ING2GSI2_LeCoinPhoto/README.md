Pour que la configuration de la base de données fonctionne, vous devez accéder au fichier application.properties (src/resources/applications.properties) Dans ce fichier indiquez votre login et votre mot de passe de base de données, situé aux deux dernières lignes du premier paragraphe du fichier. Vous aurez ensuite accès à la base
Vous pourrez ensuite importer le script sql dans votre BDD (il est directement à la racine du projet), et le site sera prêt.

Il existe deux types de sessions différentes :

La session de base (sans les accès administrateurs) : Login : nouveau 
MDP : nouveau

La session avec les droits administrateurs : Login : admin 
MDP : admin

Il suffit simplement de s'authentifier depuis le portail de connexion du site, Accessible en cliquant sur l'icone connexion à droite de la page contact sur la barre de navigation.
